document.addEventListener("DOMContentLoaded", function () {
  console.log("Navbar loaded and DOM ready!");
});



